package app.chatbot.model;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by willemchua on 5/22/17.
 */
public interface ContentRepository extends JpaRepository<Content, Integer> {

    Content findFirstByContentValue(String contentValue);
}

