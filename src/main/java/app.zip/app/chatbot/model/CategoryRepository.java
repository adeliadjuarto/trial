package app.chatbot.model;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by willemchua on 5/22/17.
 */
public interface CategoryRepository extends JpaRepository<Category, Integer> {
    Category findFirstByCategoryValue(String categoryValue);

}
