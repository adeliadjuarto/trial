package app.chatbot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by willemchua on 5/22/17.
 */
@Entity
@Table(name="content")
public class Content {

    @Id
    @Column(name="contentID")
    private Integer contentID;
    @Column(name="contentValue")
    private String contentValue;
    @Column(name="contentValueStem")
    private String contentValueStem;
    @Column(name="subcategoryID")
    private Integer subcategoryID;

    protected Content() {}

    public Content(Integer contentID, String contentValue, String contentValueStem, Integer subcategoryID) {
        this.contentID = contentID;
        this.contentValue = contentValue;
        this.contentValueStem = contentValueStem;
        this.subcategoryID = subcategoryID;
    }

    public Integer getContentID() {
        return contentID;
    }

    public void setContentID(Integer contentID) {
        this.contentID = contentID;
    }

    public String getContentValue() {
        return contentValue;
    }

    public void setContentValue(String contentValue) {
        this.contentValue = contentValue;
    }

    public Integer getSubcategoryID() {
        return subcategoryID;
    }

    public void setSubcategoryID(Integer subcategoryID) {
        this.subcategoryID = subcategoryID;
    }

}
