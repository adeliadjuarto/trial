package app.chatbot.model;

import javax.persistence.*;

/**
 * Created by willemchua on 5/22/17.
 */
@Entity
@Table(name="category")
public class Category{

    @Id
    @Column(name="categoryID")
    private Integer categoryID;
    @Column(name="categoryValue")
    private String categoryValue;

    protected Category() {}

    public Category(Integer categoryID, String categoryValue) {
        this.categoryID = categoryID;
        this.categoryValue = categoryValue;
    }

    public Integer getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(Integer categoryID) {
        this.categoryID = categoryID;
    }

    public String getCategoryValue() {
        return categoryValue;
    }

    public void setCategoryValue(String categoryValue) {
        this.categoryValue = categoryValue;
    }

}
