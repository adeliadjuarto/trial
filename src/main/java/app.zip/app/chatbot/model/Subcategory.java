package app.chatbot.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by willemchua on 5/22/17.
 */
@Entity
@Table(name="subcategory")
public class Subcategory {

    @Id
    @Column(name="subcategoryID")
    private Integer subcategoryID;
    @Column(name="subcategoryValue")
    private String subcategoryValue;
    @Column(name="categoryID")
    private Integer categoryID;

    protected Subcategory() {}

    public Subcategory(Integer subcategoryID, String subcategoryValue, Integer categoryID) {
        this.subcategoryID = subcategoryID;
        this.subcategoryValue = subcategoryValue;
        this.categoryID = categoryID;
    }

    public Integer getSubcategoryID() {
        return subcategoryID;
    }

    public void setSubcategoryID(Integer subcategoryID) {
        this.subcategoryID = subcategoryID;
    }

    public String getSubcategoryValue() {
        return subcategoryValue;
    }

    public void setSubcategoryValue(String subcategoryValue) {
        this.subcategoryValue = subcategoryValue;
    }

    public Integer getCategoryID() {
        return categoryID;
    }

    public void setCategoryID(Integer categoryID) {
        this.categoryID = categoryID;
    }

}
