package app.chatbot.model;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created by willemchua on 5/22/17.
 */
public interface SubcategoryRepository extends JpaRepository<Subcategory, Integer> {
    Subcategory findFirstBySubcategoryValue(String subcategoryValue);

    List<Subcategory> findAllByCategoryID(Integer categoryID);
}
