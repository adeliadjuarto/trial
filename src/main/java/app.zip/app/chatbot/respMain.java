package app.chatbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by willemchua on 5/8/17.
 */
@SpringBootApplication
public class respMain {

    public static void main(String args[]) throws Exception{
        SpringApplication.run(respMain.class);
    }

}
