package app.chatbot.service;

import app.chatbot.model.*;
import app.chatbot.service.querySearch.QuerySearch;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Writable;
import org.apache.mahout.common.Pair;
import org.apache.mahout.common.iterator.sequencefile.SequenceFileIterable;
import org.apache.mahout.math.Vector;
import org.apache.mahout.math.VectorWritable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by willemchua on 5/22/17.
 */
@Service
public class ChatService {

    public String searchResultTitle;
    public String searchResultContent;
    private Integer resultIndex;

    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private ContentRepository contentRepository;
    @Autowired
    private SubcategoryRepository subcategoryRepository;

    Integer chatContext = 0;
    Integer categoryIndex = -1;
    Integer subcategoryIndex = -1;

    String NOT_FOUND = "Not Found";
    String CONTENT_NOT_FOUND = "Sorry, but we still can't understand what you're looking for. Let's try this again. Say \"Hi\".";

    public void chat(String query) throws Exception {
        if(chatContext == 0)
            levelZero(query);
        else if(chatContext == 1)
            levelOne(query);
        else if(chatContext == 2)
            levelTwo(query);
        else if(chatContext == 3)
            levelThree(query);
    }

    public void levelZero(String query) throws Exception {
        if(query.equals("Hi") || query.equals("Halo")) {
            chatContext = 1;
            searchResultTitle = "Intro Message";
            String temp = "";
            for(Category i: categoryRepository.findAll()) {
                temp = temp.concat(i.getCategoryValue());
                temp = temp.concat("\n");
            }
            searchResultContent = temp;
        }
        else if(query.equals("Search")) {
            chatContext = 3;
        }
        else
            resetChat();
    }

    public void levelOne(String query) throws Exception {
        if(isCategory(query)) {
            chatContext = 2;
            categoryIndex = categoryRepository.findFirstByCategoryValue(query).getCategoryID();
            searchResultTitle = "Subcategory in " + query;
            String temp = "";
            for(Subcategory i: subcategoryRepository.findAllByCategoryID(categoryIndex)) {
                temp = temp.concat(i.getSubcategoryValue());
                temp = temp.concat("\n");
            }
            searchResultContent = temp;
        }
        else
            resetChat();
    }

    public void levelTwo(String query) throws Exception {
        if(isSubcategory(query, categoryIndex)) {
            chatContext = 3;
            searchResultTitle = "Query Search";
            searchResultContent = "Enter your query in " + query + " category";
        }
        else
            resetChat();
    }

    public void levelThree(String query) throws Exception {

        QuerySearch querySearch = new QuerySearch();

        resultIndex = querySearch.search(query);

        if(resultIndex != -1) {
            searchResultTitle = "Search Result";
            Integer resultSubcategory = getSubcategory(resultIndex);

            if(resultSubcategory == subcategoryIndex)
                searchResultContent = contentRepository.findOne(resultIndex-1).getContentValue();
            else {
                searchResultContent = "We don't find the best match of what you're looking for at " + subcategoryRepository.findOne(subcategoryIndex).getSubcategoryValue();
                searchResultContent += " However, we found a document on " + subcategoryRepository.findOne(resultSubcategory).getSubcategoryValue();
                searchResultContent += " on the category " + categoryRepository.findOne(subcategoryRepository.findOne(resultSubcategory).getCategoryID());
                searchResultContent += " that might be of interest.\n";
                searchResultContent += contentRepository.findOne(resultIndex-1).getContentValue();
            }
            reChat();
        }
        else
            resetChat();

    }

    private void reChat() {
        chatContext = 0;
    }

    private boolean isCategory(String query) throws Exception {
//        System.out.println(categoryRepository.findFirstByCategoryValue(query).)
        if(!categoryRepository.findFirstByCategoryValue(query).getCategoryValue().isEmpty())
            return true;
        return false;
//        for(Integer i: subcategoryToIndex.keySet()) {
//            Integer start = subcategoryToIndex.get(i).getFirst();
//            Integer end = subcategoryToIndex.get(i).getSecond();
//
//            if(result - start >= 0 && end - result >= 0) {
//                return i;
//            }
//        }
//
//        return -1;
    }

    private boolean isSubcategory(String query, Integer index) throws Exception {
        if(subcategoryRepository.findFirstBySubcategoryValue(query).getCategoryID() == index)
            return true;
//        for(Integer i: categoryToSubcategory.get(index)) {
//            if(subcategory.get(i).equals(query)) {
//                subcategoryIndex = i;
//                return true;
//            }
//        }
        return false;
    }

    public Integer getSubcategory(Integer result) throws Exception {
        return contentRepository.findOne(result).getSubcategoryID();

//        for(Integer i: subcategoryToIndex.keySet()) {
//            Integer start = subcategoryToIndex.get(i).getFirst();
//            Integer end = subcategoryToIndex.get(i).getSecond();
//
//            if(result - start >= 0 && end - result >= 0) {
//                return i;
//            }
//        }
//
//        return -1;
    }

    public void resetChat() throws Exception {
        chatContext = 0;
        searchResultTitle = NOT_FOUND;
        searchResultContent = CONTENT_NOT_FOUND;
    }

}
