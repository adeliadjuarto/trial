package app.chatbot.service.querySearch;

import app.chatbot.service.Hasher;
import app.chatbot.service.docProcess.FileParse;
import app.chatbot.service.docProcess.TFIDF;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.mahout.common.iterator.sequencefile.SequenceFileIterable;
import org.apache.mahout.math.*;
import org.apache.hadoop.io.Writable;
import org.apache.mahout.common.Pair;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by willemchua on 03/05/17.
 */

@Service
public class QuerySearch {

    private TFIDF tester;
    private QueryVectorizer vectorizer;
    private FileParse parser;
    private Hasher hasher;

    private List<Vector> result = new ArrayList<>();
    private List<String> docIndex = new ArrayList<>();
    private List<String> documents = new ArrayList<>();

    private Path tfidfPath = new Path("output/service");
    private String docPath = "./skbca.txt";

    public Integer search(String query) throws Exception{
        parser = new FileParse();
        tester = new TFIDF();
        hasher = new Hasher();
        vectorizer = new QueryVectorizer();

        String hashPath = docPath.replace("txt", "hash");
        String hashValue = hasher.getHash(hashPath);
        documents = parser.parse(docPath);

        if(!hashValue.isEmpty() && hashValue.equals(hasher.hash(docPath))) {
            System.out.print("TF-IDF File Exists" + '\n');
        }
//        else {
//            tester.createDocs(parser.stemDocs(documents));
//            tester.calculateTfIdf();
//        }

        SequenceFileIterable<Writable, VectorWritable> iterable = new SequenceFileIterable<> (
                new Path(tfidfPath + "/service-vectors/part-r-00000"), new Configuration());

        SequenceFileIterable<Writable, Writable> docIterable = new SequenceFileIterable<>(
                new Path("output/sequence"), new Configuration());

        for(Pair<Writable, Writable> iteration: docIterable) {
            documents.add(iteration.getSecond().toString());
        }

        vectorizer.vectorize(query);
        Vector queryVector = vectorizer.getResult();

        return Integer.parseInt(indexSearchResult(iterable, queryVector));
    }

    public String indexSearchResult(SequenceFileIterable<Writable, VectorWritable> iterable, Vector source){
        for (Pair<Writable, VectorWritable> pair : iterable) {
            Vector y = pair.getSecond().get();
            String x = pair.getFirst().toString();

            result.add(y);
            docIndex.add(x);
        }

        double maxScore = 0.0;
        int selectedIndex = -1;

        for(int i = 0; i<result.size(); i++) {
            double docScore;

            docScore = source.dot(result.get(i)) /
                    (Math.sqrt(source.getLengthSquared()) *
                            Math.sqrt(result.get(i).getLengthSquared()));

            if(docScore > maxScore) {
                maxScore = docScore;
                selectedIndex = i;
            }
        }

        if(selectedIndex == -1)
            return "Not Found";

        return docIndex.get(selectedIndex);
    }

    public Map<Integer, Pair<Integer, Integer>> unboxIndexes(List<Integer> indexes) throws Exception {
        Map<Integer, Pair<Integer, Integer>> result = new HashMap<>();

        for(int i = 0; i < indexes.size(); i+=3) {
            result.put(indexes.get(i), new Pair<>(indexes.get(i+1), indexes.get(i+2)));
        }

        return result;
    }


}
