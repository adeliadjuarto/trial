package app.chatbot.service.docProcess;

import app.chatbot.model.*;
import app.chatbot.service.Hasher;
import app.chatbot.service.Lemmatizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by willemchua on 5/4/17.
 */
@Controller
public class FileParse {

    Hasher hasher;
    public List<String> results;
    public List<String> listCategory;
    public Map<String, Integer> category;
    public Map<Integer, String> subcategory;
    public Map<Integer, List<Integer>> categoryToSubcategory;
    public Map<Integer, Integer> subcategoryToCategory;
    public List<Integer> indexes;

    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private SubcategoryRepository subcategoryRepository;
    @Autowired
    private ContentRepository contentRepository;

    public List<String> parse(String path) throws Exception{

        hasher = new Hasher();

        results = new ArrayList<>();
        category = new HashMap<>();
        subcategory = new HashMap<>();
        indexes = new ArrayList<>();
        categoryToSubcategory = new HashMap<>();
        subcategoryToCategory = new HashMap<>();
        listCategory = new ArrayList<>();

//        System.out.print("Create New File. . . " + '\n');
        BufferedReader reader = new BufferedReader(new FileReader(path));

        String currString = reader.readLine();

        Integer categoryIndex = 1;
        Integer subcategoryIndex = 1001;
        Integer contentIndex = 1;

        while(reader.ready())
        {
            if(currString.startsWith("SYARAT DAN KETENTUAN")) {
                String categoryName = currString.substring(20, currString.indexOf("PT B")).trim();
                subcategoryIndex = categoryIndex*1000 + 1;

                categoryRepository.save(new Category(categoryIndex, categoryName));
                categoryIndex++;
                currString = reader.readLine();
                continue;
            }

            Integer index = subcategoryIndex%1000;

            if(currString.startsWith(index.toString() + ". ")) {
                String subcategoryName = currString.substring(currString.indexOf(' ')).trim();
                subcategoryRepository.save(new Subcategory(subcategoryIndex, subcategoryName, categoryIndex-1));

                subcategoryIndex++;
                currString = reader.readLine();
                continue;
            }

            currString = currString.trim();

            if(!currString.isEmpty()) {
                String stemmedString = stemDocs(currString);
                contentRepository.save(new Content(contentIndex, currString, stemmedString, subcategoryIndex-1));
//                results.add(contentIndex + " " + currString);
//                dataController.insertToDatabase(contentIndex, currString, stemmedString, subcategoryIndex-1, enums.dataType.CONTENT);
                contentIndex++;
            }

            currString = reader.readLine();
        }

//        indexes.add(contentIndex-1);

//        System.out.println(subcategoryToCategory.toString());
//        System.out.println(categoryToSubcategory.toString());
//        System.out.println(category.toString());
//        System.out.println(subcategory.toString());

        hasher.createHashFile(path);
        writeIntoFile(results, path);

        return results;
    }

    public static String stemDocs(String document) throws Exception{
        Lemmatizer lemma = new Lemmatizer();

        String stemmedWords = "";
        for(String x: document.split("[ ]|[\\-]")) {
            String lemmatizedWord = lemma.lemmatize(x.replace('-', ' ').replaceAll("[^A-Za-z0-9]+", ""));
            stemmedWords = stemmedWords.concat(lemmatizedWord);
            if(!lemmatizedWord.isEmpty())
                stemmedWords = stemmedWords.concat(" ");
        }

        return stemmedWords;
    }

    public static void writeIntoFile(List<String> results, String path) throws Exception{
//
//        String alternatePath = path.replace("txt", "xxx");
//        String stemPath = path.replace("txt", "stem");
//
//        List<String> stemmedResults = stemDocs(results);
//
//        BufferedWriter docWriter = new BufferedWriter(new FileWriter(alternatePath));
//
//        for(String i: results){
//            docWriter.write(i);
//            docWriter.write('\n');
//        }
//
//        docWriter.close();
//
//        BufferedWriter writer = new BufferedWriter(new FileWriter(stemPath));
//
//        for(String i: stemmedResults){
//            writer.write(i);
//            writer.write('\n');
//        }
//
//        writer.close();
    }

}
