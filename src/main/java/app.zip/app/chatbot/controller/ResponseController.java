package app.chatbot.controller;

import app.chatbot.model.CategoryRepository;
import app.chatbot.model.ContentRepository;
import app.chatbot.model.Message;
import app.chatbot.model.SubcategoryRepository;
//import app.chatbot.service.ChatService;
import app.chatbot.service.docProcess.FileParse;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by willemchua on 5/10/17.
 */
@RestController
public class ResponseController{

    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private ContentRepository contentRepository;
    @Autowired
    private SubcategoryRepository subcategoryRepository;
    @Autowired
    private FileParse fileParse;
//    @Autowired
//    private ChatService chatService;

    @RequestMapping(value = "/chat",
                    method = RequestMethod.POST)
    public Message response(
            @RequestBody JsonNode json
            ) throws Exception{
        String body = json.get("body").asText();

//        querySearch.search(body);

//        chatService.chat(body);

//        String title = querySearch.searchResultTitle;
//        String content = querySearch.searchResultContent;
        String title = "";
        String content = "";

        return new Message(title, content);
    }

    @RequestMapping("/start")
    public Message response() throws Exception{

        System.out.println(categoryRepository.toString());
        fileParse.parse("./skbca.txt");

        return new Message("Hi", "Hai juga");
    }

}
